import { Schema } from "../../Schema";
export declare function date(): Schema<string, Date>;
