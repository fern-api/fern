"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeedAliasError = void 0;
var SeedAliasError_1 = require("./SeedAliasError");
Object.defineProperty(exports, "SeedAliasError", { enumerable: true, get: function () { return SeedAliasError_1.SeedAliasError; } });
