export declare function entries<T>(object: T): [keyof T, T[keyof T]][];
