export { getObjectLikeUtils, withParsedProperties } from "./getObjectLikeUtils";
export type { ObjectLikeSchema, ObjectLikeUtils } from "./types";
