"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeedExamplesError = void 0;
var SeedExamplesError_1 = require("./SeedExamplesError");
Object.defineProperty(exports, "SeedExamplesError", { enumerable: true, get: function () { return SeedExamplesError_1.SeedExamplesError; } });
