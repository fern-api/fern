export * as ping from "./ping";
