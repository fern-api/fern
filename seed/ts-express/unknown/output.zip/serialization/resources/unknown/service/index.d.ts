export * as post from "./post";
