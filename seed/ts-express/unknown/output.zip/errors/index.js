"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeedUnknownAsAnyError = void 0;
var SeedUnknownAsAnyError_1 = require("./SeedUnknownAsAnyError");
Object.defineProperty(exports, "SeedUnknownAsAnyError", { enumerable: true, get: function () { return SeedUnknownAsAnyError_1.SeedUnknownAsAnyError; } });
