export * from "./MyAlias";
export * from "./MyObject";
