import { ValidationError } from "../../Schema";
export declare function stringifyValidationError(error: ValidationError): string;
