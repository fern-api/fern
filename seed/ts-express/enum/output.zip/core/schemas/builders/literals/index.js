"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.booleanLiteral = exports.stringLiteral = void 0;
var stringLiteral_1 = require("./stringLiteral");
Object.defineProperty(exports, "stringLiteral", { enumerable: true, get: function () { return stringLiteral_1.stringLiteral; } });
var booleanLiteral_1 = require("./booleanLiteral");
Object.defineProperty(exports, "booleanLiteral", { enumerable: true, get: function () { return booleanLiteral_1.booleanLiteral; } });
