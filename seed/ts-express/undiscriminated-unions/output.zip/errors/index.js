"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeedUndiscriminatedUnionsError = void 0;
var SeedUndiscriminatedUnionsError_1 = require("./SeedUndiscriminatedUnionsError");
Object.defineProperty(exports, "SeedUndiscriminatedUnionsError", { enumerable: true, get: function () { return SeedUndiscriminatedUnionsError_1.SeedUndiscriminatedUnionsError; } });
