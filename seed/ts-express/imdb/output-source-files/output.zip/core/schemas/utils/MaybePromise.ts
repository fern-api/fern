export type MaybePromise<T> = T | Promise<T>;
