"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeedResponsePropertyError = void 0;
var SeedResponsePropertyError_1 = require("./SeedResponsePropertyError");
Object.defineProperty(exports, "SeedResponsePropertyError", { enumerable: true, get: function () { return SeedResponsePropertyError_1.SeedResponsePropertyError; } });
