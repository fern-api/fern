"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeedErrorPropertyError = void 0;
var SeedErrorPropertyError_1 = require("./SeedErrorPropertyError");
Object.defineProperty(exports, "SeedErrorPropertyError", { enumerable: true, get: function () { return SeedErrorPropertyError_1.SeedErrorPropertyError; } });
