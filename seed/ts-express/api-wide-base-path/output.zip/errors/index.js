"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeedApiWideBasePathError = void 0;
var SeedApiWideBasePathError_1 = require("./SeedApiWideBasePathError");
Object.defineProperty(exports, "SeedApiWideBasePathError", { enumerable: true, get: function () { return SeedApiWideBasePathError_1.SeedApiWideBasePathError; } });
