"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeedSingleUrlEnvironmentNoDefaultError = void 0;
var SeedSingleUrlEnvironmentNoDefaultError_1 = require("./SeedSingleUrlEnvironmentNoDefaultError");
Object.defineProperty(exports, "SeedSingleUrlEnvironmentNoDefaultError", { enumerable: true, get: function () { return SeedSingleUrlEnvironmentNoDefaultError_1.SeedSingleUrlEnvironmentNoDefaultError; } });
