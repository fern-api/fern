export * as dummy from "./dummy";
