import { Schema } from "../../Schema";
export declare function set<Raw, Parsed>(schema: Schema<Raw, Parsed>): Schema<Raw[], Set<Parsed>>;
