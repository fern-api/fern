export declare type MaybePromise<T> = T | Promise<T>;
