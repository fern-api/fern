export declare const boolean: () => import("../../Schema").Schema<boolean, boolean>;
