"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SendLiteralsInHeadersRequest = void 0;
var SendLiteralsInHeadersRequest_1 = require("./SendLiteralsInHeadersRequest");
Object.defineProperty(exports, "SendLiteralsInHeadersRequest", { enumerable: true, get: function () { return SendLiteralsInHeadersRequest_1.SendLiteralsInHeadersRequest; } });
