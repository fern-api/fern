"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SendLiteralsInlinedRequest = void 0;
var SendLiteralsInlinedRequest_1 = require("./SendLiteralsInlinedRequest");
Object.defineProperty(exports, "SendLiteralsInlinedRequest", { enumerable: true, get: function () { return SendLiteralsInlinedRequest_1.SendLiteralsInlinedRequest; } });
