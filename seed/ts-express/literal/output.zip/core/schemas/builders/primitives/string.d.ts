export declare const string: () => import("../../Schema").Schema<string, string>;
