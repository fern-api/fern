export declare const any: () => import("../../Schema").Schema<any, any>;
