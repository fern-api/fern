export { PostWithObjectBody } from "./PostWithObjectBody";
