import { BaseSchema } from "../Schema";
export declare function maybeSkipValidation<S extends BaseSchema<Raw, Parsed>, Raw, Parsed>(schema: S): S;
