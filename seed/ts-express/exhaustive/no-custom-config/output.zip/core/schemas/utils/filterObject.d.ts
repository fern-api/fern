export declare function filterObject<T, K extends keyof T>(obj: T, keysToInclude: K[]): Pick<T, K>;
