"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.objectWithoutOptionalProperties = void 0;
const object_1 = require("./object");
function objectWithoutOptionalProperties(schemas) {
    return (0, object_1.object)(schemas);
}
exports.objectWithoutOptionalProperties = objectWithoutOptionalProperties;
