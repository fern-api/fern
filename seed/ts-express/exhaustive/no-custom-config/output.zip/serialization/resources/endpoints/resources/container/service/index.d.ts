export * as getAndReturnListOfPrimitives from "./getAndReturnListOfPrimitives";
export * as getAndReturnListOfObjects from "./getAndReturnListOfObjects";
export * as getAndReturnSetOfPrimitives from "./getAndReturnSetOfPrimitives";
export * as getAndReturnSetOfObjects from "./getAndReturnSetOfObjects";
export * as getAndReturnMapPrimToPrim from "./getAndReturnMapPrimToPrim";
export * as getAndReturnMapOfPrimToObject from "./getAndReturnMapOfPrimToObject";
export * as getAndReturnOptional from "./getAndReturnOptional";
