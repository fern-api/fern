"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostWithObjectBody = void 0;
var PostWithObjectBody_1 = require("./PostWithObjectBody");
Object.defineProperty(exports, "PostWithObjectBody", { enumerable: true, get: function () { return PostWithObjectBody_1.PostWithObjectBody; } });
