"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BootInstanceRequest = void 0;
var BootInstanceRequest_1 = require("./BootInstanceRequest");
Object.defineProperty(exports, "BootInstanceRequest", { enumerable: true, get: function () { return BootInstanceRequest_1.BootInstanceRequest; } });
