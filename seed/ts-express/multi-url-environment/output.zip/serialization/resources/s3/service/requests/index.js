"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetPresignedUrlRequest = void 0;
var GetPresignedUrlRequest_1 = require("./GetPresignedUrlRequest");
Object.defineProperty(exports, "GetPresignedUrlRequest", { enumerable: true, get: function () { return GetPresignedUrlRequest_1.GetPresignedUrlRequest; } });
