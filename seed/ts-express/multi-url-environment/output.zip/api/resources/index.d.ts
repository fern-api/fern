export * as ec2 from "./ec2";
export * from "./ec2/service/requests";
export * as s3 from "./s3";
export * from "./s3/service/requests";
