export { lazy } from "./lazy";
export type { SchemaGetter } from "./lazy";
export { lazyObject } from "./lazyObject";
