export declare function keys<T>(object: T): (keyof T)[];
