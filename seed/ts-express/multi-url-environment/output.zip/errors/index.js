"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeedMultiUrlEnvironmentError = void 0;
var SeedMultiUrlEnvironmentError_1 = require("./SeedMultiUrlEnvironmentError");
Object.defineProperty(exports, "SeedMultiUrlEnvironmentError", { enumerable: true, get: function () { return SeedMultiUrlEnvironmentError_1.SeedMultiUrlEnvironmentError; } });
