import { Schema } from "../../Schema";
export declare function stringLiteral<V extends string>(literal: V): Schema<V, V>;
