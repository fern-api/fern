export declare function getErrorMessageForIncorrectType(value: unknown, expectedType: string): string;
