export * from "./GetShapeRequest";
export * from "./Shape";
export * from "./Circle";
export * from "./Square";
