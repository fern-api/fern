import { Schema } from "../../Schema";
export declare function list<Raw, Parsed>(schema: Schema<Raw, Parsed>): Schema<Raw[], Parsed[]>;
