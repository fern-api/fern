"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.record = void 0;
var record_1 = require("./record");
Object.defineProperty(exports, "record", { enumerable: true, get: function () { return record_1.record; } });
