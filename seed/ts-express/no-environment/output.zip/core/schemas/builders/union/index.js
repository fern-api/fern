"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.union = exports.discriminant = void 0;
var discriminant_1 = require("./discriminant");
Object.defineProperty(exports, "discriminant", { enumerable: true, get: function () { return discriminant_1.discriminant; } });
var union_1 = require("./union");
Object.defineProperty(exports, "union", { enumerable: true, get: function () { return union_1.union; } });
