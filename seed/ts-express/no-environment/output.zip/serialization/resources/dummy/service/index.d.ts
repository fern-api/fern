export * as getDummy from "./getDummy";
