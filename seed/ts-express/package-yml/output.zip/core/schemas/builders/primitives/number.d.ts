export declare const number: () => import("../../Schema").Schema<number, number>;
