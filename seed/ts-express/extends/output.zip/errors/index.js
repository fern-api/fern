"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeedExtendsError = void 0;
var SeedExtendsError_1 = require("./SeedExtendsError");
Object.defineProperty(exports, "SeedExtendsError", { enumerable: true, get: function () { return SeedExtendsError_1.SeedExtendsError; } });
