"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.entries = void 0;
function entries(object) {
    return Object.entries(object);
}
exports.entries = entries;
