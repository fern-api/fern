"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeedCustomAuthError = void 0;
var SeedCustomAuthError_1 = require("./SeedCustomAuthError");
Object.defineProperty(exports, "SeedCustomAuthError", { enumerable: true, get: function () { return SeedCustomAuthError_1.SeedCustomAuthError; } });
