import { Schema } from "../../Schema";
export declare function booleanLiteral<V extends boolean>(literal: V): Schema<V, V>;
