export declare const unknown: () => import("../../Schema").Schema<unknown, unknown>;
