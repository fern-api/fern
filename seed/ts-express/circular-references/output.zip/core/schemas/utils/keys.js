"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.keys = void 0;
function keys(object) {
    return Object.keys(object);
}
exports.keys = keys;
