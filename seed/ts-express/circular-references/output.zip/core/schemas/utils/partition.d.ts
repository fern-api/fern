export declare function partition<T>(items: readonly T[], predicate: (item: T) => boolean): [T[], T[]];
